from flask import Flask, render_template,request
import os 
import time
import cv2 
from skimage.transform import resize
import numpy as np 
from tensorflow import keras
model = keras.models.load_model('model.h5')

face_cascade = cv2.CascadeClassifier('haarcascade_frontalface_default.xml')


app = Flask(__name__,template_folder='./content/',static_folder='./content/')

@app.route('/')
def home():
    return render_template('index.html')


@app.route("/detect", methods=['POST','GET'])
def predict():
    if request.method=='POST':
        vidfile = request.files['vid']
        if os.path.exists("content\output.mp4"):
            os.remove("content\output.mp4")
        if vidfile:
            filename = vidfile.filename
            path = os.path.join('content',filename)
            vidfile.save(path)
            time.sleep(2)
            outfile =  cv2.VideoWriter("./content/output.mp4",cv2.VideoWriter_fourcc('m', 'p', '4', 'v'), 30,(1920,1080))
            cap = cv2.VideoCapture(path)
            length = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
            for k in range(0,length,30):
                success, frame = cap.read()
                try:
                    image = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                except:
                    continue
                # face_locations = face_recognition.face_locations(image)
                gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
                faces = face_cascade.detectMultiScale(gray, 1.1, 4)
                for (x, y, w, h) in faces:
                    if w>200 and h > 200:
                        face_locations = [(x, y, w, h)]
                if len(face_locations) > 0:
                    face_location = face_locations[0]

                    # top, right, bottom, left = face_location
                    # face_image = image[top:bottom, left:right]
                    # print(face_image.shape)
                    # face_image = resize(face_image,(224,224))
                    x, y, w, h = face_location
                    face_image = image[y:y+h,x:x+w]
                    face_image = resize(face_image,(224,224))
                    out = model.predict(np.expand_dims(face_image ,axis=0))
                    result = np.argmax(out,axis=1)
                    flag = 0
                    if not result[0]:
                        # print('fake')
                        txt = "deep fake"
                        flag = 1
                    else:
                        # print('real')
                        txt ="real"
                    if flag:
                        msg ="deep fake"
                    else:
                        msg = " no deep fakes"
                    cv2.rectangle(frame, (x, y), (x+w, y+h), (255, 0, 0), 2)
                    font = cv2.FONT_HERSHEY_SIMPLEX
                    cv2.putText(frame, txt, (x, y - 2), font, 2.5, (0, 0, 255), thickness=8, lineType=cv2.LINE_AA)
                outfile.write(frame)
                
            time.sleep(10)    
            return render_template('index.html', msg=msg,filename=filename)
        else:
            return render_template('index.html', msg="No file")

    elif request.method=='GET':
        return render_template('index.html', prediction_text="Get Method")



if __name__ == "__main__":
    app.run(debug=True)